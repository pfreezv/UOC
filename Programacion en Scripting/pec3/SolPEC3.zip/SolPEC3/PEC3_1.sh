grep -E  "^([1-8][0-9]|9[0-8]),F,(1[0-9]|3[0-9]),finnish,((.*french.*)+|.(*spanish.*)+)" demographic_info.csv
