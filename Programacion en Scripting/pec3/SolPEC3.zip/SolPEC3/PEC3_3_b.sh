sed '2,$ s/^\(.*\)\(,.*\)\(,.*\)/\1\U\2\E\3/' demographic_info.csv
