#!/bin/bash

grep -E '[1-9][0-9],F,[1,3][0-9],finnish,(.*french.spanish|.*spanish.french)' demographic_info.csv

