#!/bin/bash

sed 's/\b\(.\)/\u\1/7' demographic_info.csv
