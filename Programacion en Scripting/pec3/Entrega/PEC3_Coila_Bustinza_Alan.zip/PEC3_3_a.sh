#!/bin/bash

sed -n 's/M/Male/p;s/F/Female/p' demographic_info.csv


